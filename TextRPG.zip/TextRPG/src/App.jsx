/* eslint-disable react/no-unescaped-entities */
import { useState, useEffect } from "react";
import ItemNumber from "./components/ItemNumbers";

let numberFocus = 0;
let reNumber = 0;

function App() {
  const [time, setTime] = useState(reNumber);
  const [quantity, setQuantity] = useState();
  const [start, setStart] = useState(false);
  const [arrNumber, setArrNumber] = useState([]);
  const [isWin, setIsWin] = useState(false);

  useEffect(() => {
    setTime((pre) => pre);

    let timeId;
    if (start) {
      timeId = setInterval(() => {
        setTime((pre) => {
          let number = pre + 0.1;
          return parseFloat(number.toFixed(1));
        });
      }, 100);
    }

    return () => clearInterval(timeId);
  }, [start]);

  const handleStart = (quantity) => {
    setArrNumber([]);
    setTime(reNumber);
    for (let i = 0; i < quantity; i++) {
      const number = {
        id: i + 1,
        number: i + 1,
        isActive: true,
      };

      setStart(true);
      setArrNumber((arrOld) => [...arrOld, number]);
    }
  };

  const handleDelete = (id) => {
    if (id === numberFocus + 1) {
      setArrNumber((arrOld) => arrOld.filter((item) => item.id !== id));
    } else {
      setIsWin(false);
      setStart(false);
      numberFocus = 0;
      id = 0;
    }

    numberFocus = id;
  };

  return (
    <>
      <div className="w-[90vw] h-[95vh] flex justify-center items-center flex-col">
        <div className="flex flex-col w-[40%] h-[100%] gap-4 border-2 border-black p-3">
          <div className=" ">
            <h1 className="font-bold text-3xl mb-4">LET'S PLAY</h1>
            <div className="h-full">
              <div className="h-auto">
                <label htmlFor="quantity">Points :</label>
                <input
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  type="text"
                  id="quantity"
                  className="ml-5 border-2 border-black p-2 text-[15px] w-[30%]"
                />
              </div>
              <div className="mb-3">
                <label className="mr-6">Time : </label>
                <span>{time} s</span>
              </div>

              <button
                onClick={() => handleStart(quantity)}
                className="px-5 py-1 border-2 border-black"
              >
                Restart
              </button>
            </div>
          </div>
          <div className="h-[90%] border-2 border-black p-2">
            {arrNumber.map((item) => (
              <ItemNumber
                click={handleDelete}
                key={item.id}
                number={item.number}
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
