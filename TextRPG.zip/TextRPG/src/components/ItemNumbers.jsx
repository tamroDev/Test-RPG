function ItemNumber({ number, click }) {
  return (
    <button
      onClick={() => click(number)}
      className="font-bold w-[30px] h-[30px] border border-black rounded-full flex justify-center items-center cursor-pointer transition-all duration-400 focus:bg-red-500"
    >
      {number}
    </button>
  );
}

export default ItemNumber;
